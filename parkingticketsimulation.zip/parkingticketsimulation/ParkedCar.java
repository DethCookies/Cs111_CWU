package parkingTicketSimulation;
/*
 * The ParkedCar class is intended to hold data about cars including their make, model, color, lisensePlate, and time parked.
 * 
 * I pledge that this submission is solely my work, and that I have neither given, nor received help from anyone.
 * @Author Bentley Bowen
 * Student ID: 49820909
 * @since 24
 */
public class ParkedCar {
	private String make = "";
	private String model = "";
	private String color = "";
	private String lisencePlate = "";
	private int minutesParked = 0;
	/*
	 * A constructor of class ParkedCar. This constructor takes 4 strings and an integer applying them to the variables, make, model, color, lisensePlate, and minutesParked.
	 */
	public ParkedCar(String make, String model, String color, String lisencePlate, int minutesParked) {
		this.make = make;
		this.model = model;
		this.color = color;
		this.lisencePlate = lisencePlate;
		this.minutesParked = minutesParked;
	}
	/*
	 * A copy constructor of class ParkedCar. This constructor takes another car and uses all of its variables to assign this instance's variables
	 */
	public ParkedCar(ParkedCar car) {
		make = car.getMake();
		model = car.getModel();
		color = car.getColor();
		lisencePlate = car.getLisencePlate();
		minutesParked = car.getMinutesParked();
	}
	public String toString() {
		return "Make: " + make + "\nModel:" + model + "\nColor: " + color + "\nLisence Plate: " + lisencePlate + "\nMinutes Parked: " +minutesParked;
	}
	/*
	 * Getter methods for the variables.
	 */
	public String getMake() {
		return make;
	}
	public String getModel() {
		return model;
	}
	public String getColor() {
		return color;
	}
	public String getLisencePlate() {
		return lisencePlate;
	}
	public int getMinutesParked() {
		return minutesParked;
	}
	/*
	 * Setter methods for the variables.
	 */
	public void setMake(String make) {
		this.make = make;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public void setLisencePlate(String lisencePlate) {
		this.lisencePlate = lisencePlate;
	}
	public void setMinutesParked(int minutesParked) {
		this.minutesParked = minutesParked; 
	}
	
}
