package parkingTicketSimulation;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
/*
 * The Simulation class holds the main method of the program and two static methods that are used to read files.
 * 
 * I pledge that this submission is solely my work, and that I have neither given, nor received help from anyone.
 * @Author Bentley Bowen
 * Student ID: 49820909
 * @since 24
 */
public class Simulation {
	/*
	 * The main method creates a parking lot of cars and their associated meters using the text files and text file reading methods. 
	 * Then it simulates a patrol counting the number of illegal cars and printing any Toyotas with a greater then 30 dollar fine.
	 * Finally, it prints out the statistics of total legal cars, illegal cars, and money made. 
	 * @see readCarFile
	 * @see readParkingMeterFile
	 */
	public static void main(String[] args) throws FileNotFoundException {
		int illegalCars = 0;
		double totalFine = 0;
		ParkedCar[] parkingLot = readCarFile("C:\\Users\\bentl\\eclipse-workspace\\parkingTicketSimulation\\src\\parkingTicketSimulation/CarData.txt", 1000);
		ParkingMeter[] meters = readParkingMeterFile("C:\\Users\\bentl\\eclipse-workspace\\parkingTicketSimulation\\src\\parkingTicketSimulation/MeterData.txt", 1000);
		PoliceOfficer currentPatroller = new PoliceOfficer("Bentley Bowen", "1175");
		ParkingTicket[] tickets = new ParkingTicket[1000];
		/*
		 * Patrol
		 */
		for(int i = 0; i<1000; i++) {
			tickets[i] = currentPatroller.patrol(parkingLot[i], meters[i]);
			/*
			 * Checks if illegal. Then checks if Toyota and fine is above 30 dollars. Finally, if all checks are true prints out information about class.
			 */
			if(!(tickets[i]==null)) {
				illegalCars++;
				totalFine += tickets[i].getFine();
				if(tickets[i].getParkedCar().getMake().equals("Toyota")&&tickets[i].getFine()>30) {
					System.out.println(tickets[i].getParkedCar());
					System.out.println("Officer Data:\n"+tickets[i].getPoliceOfficer());
					System.out.println(tickets[i]+"\n");
				}
			}
		}
		System.out.println(1000-illegalCars + " cars parked legally.\n" + illegalCars + " cars parked illegally.\n" + "City got $" + totalFine + " from parking tickets.");
	}
	/*
	 * The readCarFile method of class Simulation. Takes a file location and size of file then returns an array of type ParkedCar using data from the file.
	 */
	public static ParkedCar[] readCarFile(String file, int sizeFile) throws FileNotFoundException {
		File carFile = new File(file);
		Scanner fileScanner = new Scanner(carFile);
		ParkedCar[] parkingLot = new ParkedCar[sizeFile];
		String[] carData = new String[5];
		for(int i = 0; i<sizeFile; i++) {
			carData = fileScanner.nextLine().split(",");
			parkingLot[i] = new ParkedCar(carData[0], carData[1], carData[2], carData[3], Integer.parseInt(carData[4]));
		}
		fileScanner.close();
		return parkingLot;
	}
	/*
	 * The readParkingMeterFile of class Simulation. Takes the file location and size of file and returns an array of type ParkingMeter using data from the file.
	 */
	public static ParkingMeter[] readParkingMeterFile(String file, int sizeFile) throws FileNotFoundException {
		File parkingFile = new File(file);
		Scanner fileScanner = new Scanner(parkingFile);
		ParkingMeter[] meters = new ParkingMeter[sizeFile];
		for(int i = 0; i<sizeFile; i++) {
			meters[i] = new ParkingMeter(Integer.parseInt(fileScanner.nextLine()));
		}
		fileScanner.close();
		return meters;
	}

}
