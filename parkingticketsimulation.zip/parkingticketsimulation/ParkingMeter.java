package parkingTicketSimulation;
/*
 * The ParkingMeter class holds data about the minutes purchased in each parking meter.
 * 
 * I pledge that this submission is solely my work, and that I have neither given, nor received help from anyone.
 * @Author Bentley Bowen
 * Student ID: 49820909
 * @since 24 
 */
public class ParkingMeter {
	int minutesPurchased = 0;
	/*
	 * The constructor of class ParkingMeter. Takes an integer that corresponds to the time purchased in minutes.
	 */
	public ParkingMeter(int minutesPurchased) {
		this.minutesPurchased = minutesPurchased;
	}
	public String toString() {
		return "Minutes Purchased: " + minutesPurchased;
	}
	/*
	 * The getter and setter methods of class ParkingMeter.
	 */
	public int getMinutesPurchased() {
		return minutesPurchased;
	}
	public void setMinutesPurchased(int minutesPurchased) {
		this.minutesPurchased = minutesPurchased; 
	}
}
