package parkingTicketSimulation;
/*
 * The policeOfficer class holds data about the officer on patrol including their name and badge number. 
 * It also has a patrol method that simulates a officer giving out tickets.
 * 
 * I pledge that this submission is solely my work, and that I have neither given, nor received help from anyone.
 * @Author Bentley Bowen
 * Student ID: 49820909
 * @since 24
 */
public class PoliceOfficer {
	String name = "";
	String badgeNumber = "";
	/*
	 * A constructor of class PoliceOfficer. This constructor takes 2 strings and assigns them to name and badgeNumber.
	 */
	public PoliceOfficer(String name, String badgeNumber) {
		this.name = name;
		this.badgeNumber = badgeNumber;
	}
	/*
	 * A copy constructor of class PoliceOfficer. Takes another PoliceOfficer and uses its variables to assign this instance's variables.
	 */
	public PoliceOfficer(PoliceOfficer officer) {
		name = officer.getName();
		badgeNumber = officer.getBadgeNumber();
	}
	/*
	 * The patrol method of class PoliceOfficer. Takes a ParkedCar and ParkingMeter then returns a ParkingTicket if they are over purchased time or null if they are under.
	 * @see ParkedCar
	 * @see ParkingMeter
	 * @see ParkingTicket
	 */
	public ParkingTicket patrol(ParkedCar car, ParkingMeter meter) {
		if(car.getMinutesParked() > meter.getMinutesPurchased()) {
			return new ParkingTicket(car, this, meter.getMinutesPurchased());
		}
		else {
			return null;
		}
	}
	public String toString() {
		return "Name: " + name + "\nBadge Number: " + badgeNumber;
	}
	/*
	 * The getter methods of class PoliceOfficer.
	 */
	public String getName() {
		return name;
	}
	public String getBadgeNumber() {
		return badgeNumber;
	}
	/*
	 * The setter methods of class PoliceOfficer.
	 */
	public void setName(String name) {
		this.name = name;
	}
	public void setBadgeNumber(String badgeNumber) {
		this.badgeNumber = badgeNumber;
	}
}
