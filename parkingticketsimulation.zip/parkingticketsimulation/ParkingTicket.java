package parkingTicketSimulation;
/*
 * The Parking Ticket class holds data on the car, officer, time over purchased time, and the fine. It also calculates the amount fined.
 * 
 * I pledge that this submission is solely my work, and that I have neither given, nor received help from anyone.
 * @Author Bentley Bowen
 * Student ID: 49820909
 * @since 24
 */
public class ParkingTicket {
	private ParkedCar car = null;
	private PoliceOfficer officer = null;
	private double fine = 0f;
	/*
	 * Length of time in minutes the car is over purchased time.
	 */
	private int minutes = 0;
	public static double base_fine = 25;
	public static double hourly_fine = 10;
	/*
	 * A constructor of class ParkingTicket. This constructor takes in a ParkedCar, a PoliceOfficer, and the amount of time paid for.
	 * Then runs the method calculateFine.
	 * @see ParkedCar
	 * @see PoliceOfficer
	 * @see calculateFine
	 */
	public ParkingTicket(ParkedCar car, PoliceOfficer officer, int meterMinutes) {
		this.car = car;
		this.officer = officer;
		this.minutes = car.getMinutesParked()-meterMinutes;
		calculateFine();
	}
	/*
	 * A copy constructor of class ParkingTicket. This constructor takes in a ParkingTicket and uses its variables to assign this instance's variables.
	 * Then runs the method calculateFine.
	 * @see calculateFine
	 */
	public ParkingTicket(ParkingTicket ticket) {
		car = ticket.getParkedCar();
		officer = ticket.getPoliceOfficer();
		minutes = ticket.getMinutes();
		calculateFine();
	}
	/*
	 * The calculateFine method of class ParkingTicket. This method uses the variables minutes, base_fine, and hourly_fine to determine the total fine of the individual car.
	 * @see minutes
	 */
	public void calculateFine() {
		double hoursOver = (minutes)/60.0;
		/*
		 * If over an hour fine is base_fine + total hourly_fine. If not then fine is base_fine.
		 */
		if(hoursOver>1) {
			
			fine = base_fine + (Math.ceil(hoursOver-1))*hourly_fine;
		}
		else {
			fine = base_fine;
		}
	}
	public String toString() {
		return "Minutes illegally parked: " + minutes + "\nfine: " + fine;
	}
	/*
	 * The getter methods of class ParkingTicket.
	 */
	public ParkedCar getParkedCar() {
		return car;
	}
	public PoliceOfficer getPoliceOfficer() {
		return officer;
	}
	public int getMinutes() {
		return minutes;
	}
	public double getFine() {
		return fine;
	}
	/*
	 * The setter methods of class ParkingTicket. Any that may effect the fine calculation rerun method calculateFine.
	 * @see calculateFine
	 */
	public void setParkedCar(ParkedCar car) {
		this.car = car;
		calculateFine();
	}
	public void setPoliceOfficer(PoliceOfficer officer) {
		this.officer = officer;
	}
	public void setMinutes(int minutes) {
		this.minutes = minutes;
		calculateFine();
	}
}
