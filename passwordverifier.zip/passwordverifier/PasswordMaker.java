package passwordVerifier;
import java.util.Scanner;
/*
 * The class PasswordMaker holds the main method. 
 * 
 * I pledge that this submission is solely my work, and that I have neither given, nor received help from anyone.
 * @Author Bentley Bowen
 * Student ID: 49820909
 * @since 24
 */
public class PasswordMaker {
	/*
	 * The main method has the user input a password and then it inputs the password into the password verifier class determining if it is valid or not.
	 */
	public static void main(String[] args) {
		Scanner userInput = new Scanner(System.in);
		System.out.print("Please insert password: ");
		if(PasswordVerifier.isValid(userInput.nextLine())) {
			System.out.println("The password is valid.");			}
		else {
			System.out.println("The password is not valid.");
		}
		userInput.close();
	}

}
