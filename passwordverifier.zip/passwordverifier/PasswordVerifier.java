package passwordVerifier;
/*
 * The class PasswordVerifier has multiple methods that are used to determine if a password would be valid or not.
 * 
 * I pledge that this submission is solely my work, and that I have neither given, nor received help from anyone.
 * @Author Bentley Bowen
 * Student ID: 49820909
 * @since 24
 */
public class PasswordVerifier {
	private static final byte minPasswordLength = 7;
	/*
	 * The main checking method of class PasswordVerifier. It uses all other methods in the class to determine if the inputed password is valid.
	 * @see hasDigit()
	 * @see hasUpperCase()
	 * @see hasLowerCase()
	 */
	public static boolean isValid(String password) {
		boolean valid = true;
		if(!(password.length()>=minPasswordLength)) {
			System.out.println("The password is not larger then the minimum length of 7.");
			valid = false;
		}
		if(!hasDigit(password)) {
			System.out.println("The password is missing a number.");
			valid = false;
		}
		if(!hasUpperCase(password)) {
			System.out.println("The password is missing an upper case letter.");
			valid = false;
		}
		if(!hasLowerCase(password)) {
			System.out.println("The password is missing a lower case letter.");
			valid = false;
		}
		return valid;
		
		
	}
	/*
	 * The method hasDigit takes the password and returns true if it has a number and false if it does not.
	 */
	public static boolean hasDigit(String password) {
		for(int i = 0; i<password.length(); i++) {
			if(Character.isDigit(password.charAt(i))) {
				return true;
			}
		}
		return false;
	}
	/*
	 * The method hasUpperCase takes the password and returns true if it has a upper case letter and false if it does not.
	 */
	public static boolean hasUpperCase(String password) {
		for(int i = 0; i<password.length(); i++) {
			if(Character.isUpperCase(password.charAt(i))) {
				return true;
			}
		}
		return false;
	}
	/*
	 * The method hasLowerCase takes the password and returns true if it has a lower case and false if it does not.
	 */
	public static boolean hasLowerCase(String password) {
		for(int i = 0; i<password.length(); i++) {
			if(Character.isLowerCase(password.charAt(i))) {
				return true;
			}
		}
		return false;
	}
}
